# Campus Bites — Website + Android-ready app

## Included
- Responsive college canteen website
- Installable Progressive Web App (PWA) for Android phones
- Menu filters, cart, demo checkout and order history
- Cart and order history saved in the browser on that device

## Preview locally
Open `index.html` in a browser. For install/offline support, serve the folder over HTTPS or use localhost (service workers do not run from ordinary `file://` pages).

## Publish the website
Upload the contents of this folder to a static host such as GitHub Pages, Netlify or Cloudflare Pages. After publishing over HTTPS, open the site on Android Chrome and choose **Install app** / **Add to Home screen**.

## Build an Android APK with Capacitor
You need Node.js and Android Studio on a computer.
1. In this folder run: `npm install`
2. Run: `npx cap add android`
3. Run: `npx cap sync android`
4. Run: `npx cap open android`
5. In Android Studio, build an APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated APK can then be installed on a compatible Android phone. APK signing/distribution is a separate Android Studio step.

## Important demo limitations
The checkout is a front-end demo. It does not send orders to a canteen, process payments, or provide an admin/backend system. Add your real canteen name, menu, prices, address and contact details before publishing. Food photos are loaded from Unsplash and need internet access.
