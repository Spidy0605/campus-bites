import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.campusbites.canteen', appName: 'Campus Bites', webDir: '.' };
export default config;
